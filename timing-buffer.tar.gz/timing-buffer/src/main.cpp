// Timing Buffer - simple Geode mod that delays early clicks
// Inspired by Predictive Input Buffer style logs
//
// Stages (F6 cycle):
//   0: 2 ticks all / 2 wave   (~0.5 frames @ 60fps)
//   1: 4 ticks all / 4 wave   (~1.0 frames)
//   2: 8 ticks all / 8 wave   (~2.0 frames)
//   3: 16 ticks all / 8 wave  (~4.0 / 2.0 frames)
//   4: OFF (raw input)
//
// 1 tick = 1/240s physics step. 4 ticks ≈ 1 visual frame at 60fps.

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/CCKeyboardDispatcher.hpp>
#include <deque>

using namespace geode::prelude;

namespace buffer {
    struct Stage {
        int all;
        int wave;
        const char* name;
    };

    constexpr Stage STAGES[] = {
        {2,  2,  "STAGE 1: 2 Ticks All | 2 Ticks Wave (0.5f @ 60fps)"},
        {4,  4,  "STAGE 2: 4 Ticks All | 4 Ticks Wave (1.0f @ 60fps)"},
        {8,  8,  "STAGE 3: 8 Ticks All | 8 Ticks Wave (2.0f @ 60fps)"},
        {16, 8,  "STAGE 4: 16 Ticks All | 8 Ticks Wave (4.0f / 2.0f @ 60fps)"},
        {0,  0,  "STAGE 5: OFF (100% Raw Input)"}
    };

    inline int g_stage = 2; // default to 8-tick stage

    inline bool verbose() {
        return Mod::get()->getSettingValue<bool>("verbose-log");
    }

    inline void logStage() {
        log::info("[InputBuffer] F6 Cycle -> {}", STAGES[g_stage].name);
    }

    inline void loadStartStage() {
        g_stage = Mod::get()->getSettingValue<int>("start-stage");
        if (g_stage < 0 || g_stage > 4) g_stage = 2;
    }
}

struct PendingInput {
    bool down;
    int button;
    bool player1;
    int remaining;
};

class $modify(TimingBufferLayer, GJBaseGameLayer) {
    struct Fields {
        std::deque<PendingInput> queue;
        bool applying = false;
    };

    void handleButton(bool down, int button, bool isPlayer1) {
        auto f = m_fields.self();

        // Pass through if disabled, or if we're re-injecting a buffered input
        if (f->applying || buffer::g_stage == 4) {
            GJBaseGameLayer::handleButton(down, button, isPlayer1);
            return;
        }

        auto* player = isPlayer1 ? m_player1 : m_player2;
        bool isWave = player && player->m_isDart;
        auto& stage = buffer::STAGES[buffer::g_stage];
        int delay = isWave ? stage.wave : stage.all;

        if (delay <= 0) {
            GJBaseGameLayer::handleButton(down, button, isPlayer1);
            return;
        }

        f->queue.push_back({down, button, isPlayer1, delay});

        if (buffer::verbose()) {
            float frames = delay / 4.0f;
            log::info(
                "[InputBuffer] *** SAVED +{} TICKS ({:.2f} frames @ 60fps) {}! [Limit: {}] ***",
                delay, frames, down ? "PRESS" : "RELEASE", delay
            );
        }
    }

    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        auto f = m_fields.self();

        for (auto it = f->queue.begin(); it != f->queue.end();) {
            it->remaining -= 1;
            if (it->remaining <= 0) {
                f->applying = true;
                GJBaseGameLayer::handleButton(it->down, it->button, it->player1);
                f->applying = false;
                it = f->queue.erase(it);
            } else {
                ++it;
            }
        }

        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
    }
};

class $modify(TimingBufferPlayLayer, PlayLayer) {
    void resetLevel() {
        // Clear pending inputs on restart so nothing carries over
        if (auto* base = static_cast<TimingBufferLayer*>(static_cast<GJBaseGameLayer*>(this))) {
            base->m_fields->queue.clear();
        }
        PlayLayer::resetLevel();
    }
};

class $modify(TimingBufferKeyboard, CCKeyboardDispatcher) {
    bool dispatchKeyboardMSG(enumKeyCodes key, bool down, bool repeat, double timestamp) {
        if (down && !repeat && key == KEY_F6) {
            buffer::g_stage = (buffer::g_stage + 1) % 5;
            buffer::logStage();
            return true; // consume the key so GD doesn't also see it
        }
        return CCKeyboardDispatcher::dispatchKeyboardMSG(key, down, repeat, timestamp);
    }
};

$on_mod(Loaded) {
    buffer::loadStartStage();
    log::info("============================================================");
    log::info("[InputBuffer] Timing Buffer loaded");
    log::info("[InputBuffer] Press F6 in a level to cycle stages");
    buffer::logStage();
    log::info("============================================================");
}
