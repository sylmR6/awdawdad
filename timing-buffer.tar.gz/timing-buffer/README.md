# Timing Buffer

Simple Geometry Dash Geode mod that buffers and delays your clicks.

If you click a little early, the mod holds the input and fires it a few ticks later. This can help pass tight frame-perfect windows.

## Stages (press F6 in a level to cycle)

| Stage | All modes | Wave | Approx. frames @ 60fps |
|-------|-----------|------|------------------------|
| 1     | 2 ticks   | 2    | 0.5                    |
| 2     | 4 ticks   | 4    | 1.0                    |
| 3     | 8 ticks   | 8    | 2.0                    |
| 4     | 16 ticks  | 8    | 4.0 / 2.0              |
| 5     | OFF       | OFF  | Raw input              |

## How to build

1. Install the Geode CLI and SDK:  
   https://docs.geode-sdk.org/getting-started/geode-cli

2. Make sure `GEODE_SDK` is set and you have run `geode sdk install` + `geode sdk install-binaries`.

3. Open a terminal in this folder and run:
   ```
   geode build
   ```

4. The `.geode` file will appear in the `build` folder.  
   Copy it to `Geometry Dash/geode/mods/` and restart the game.

## Usage

- Enable the mod in the Geode menu.
- In a level, press **F6** to cycle the buffer size.
- The Geode console (or the game log) will show when inputs are delayed if “Console Logging” is on.
- Best used for practice. Not recommended for rated levels / leaderboards.

## Notes

- This is a fixed-delay buffer, not a full trajectory-prediction system.
- More advanced predictive versions exist (search “Predictive Input Buffer” on GitHub).
- Works best on 60 / 120 / 240 FPS or with Physics Bypass.
- Compatible with most other mods; if something feels off, try disabling Click Between Frames / other input mods.
